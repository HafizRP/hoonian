<?php $__env->startSection('title', 'My Bidding List - Property'); ?>

<?php $__env->startSection('content'); ?>
    <div class="hero page-inner overlay" style="background-image: url('<?php echo e(asset('images/hero_bg_1.jpg')); ?>')">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-9 text-center">
                    <h1 class="heading" data-aos="fade-up"><i class="fas fa-gavel me-3"></i> My Bidding List</h1>
                    <nav aria-label="breadcrumb" data-aos="fade-up" data-aos-delay="200">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('main')); ?>">Home</a></li>
                            <li class="breadcrumb-item active text-white-50" aria-current="page">Bidding</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="section">
        <div class="container">
            
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center">
                            <div class="mb-2">
                                <i class="fas fa-inbox fa-2x text-primary"></i>
                            </div>
                            <h3 class="mb-0"><?php echo e($sellingBids->count()); ?></h3>
                            <p class="text-muted mb-0 small">Offers Received</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center">
                            <div class="mb-2">
                                <i class="fas fa-paper-plane fa-2x text-success"></i>
                            </div>
                            <h3 class="mb-0"><?php echo e($buyingBids->count()); ?></h3>
                            <p class="text-muted mb-0 small">Bids Placed</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center">
                            <div class="mb-2">
                                <i class="fas fa-trophy fa-2x text-warning"></i>
                            </div>
                            <h3 class="mb-0"><?php echo e($sellingBids->where('status', 'leading')->count() + $buyingBids->where('status', 'leading')->count()); ?></h3>
                            <p class="text-muted mb-0 small">Leading Bids</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center">
                            <div class="mb-2">
                                <i class="fas fa-check-circle fa-2x text-info"></i>
                            </div>
                            <h3 class="mb-0"><?php echo e($sellingBids->where('status', 'accepted')->count() + $buyingBids->where('status', 'accepted')->count()); ?></h3>
                            <p class="text-muted mb-0 small">Accepted</p>
                        </div>
                    </div>
                </div>
            </div>

            
            <ul class="nav nav-pills mb-4 justify-content-center fs-5" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="pills-selling-tab" data-bs-toggle="pill" data-bs-target="#pills-selling" type="button" role="tab" aria-controls="pills-selling" aria-selected="true">
                        <i class="fas fa-home me-2"></i> Offers on My Properties
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="pills-buying-tab" data-bs-toggle="pill" data-bs-target="#pills-buying" type="button" role="tab" aria-controls="pills-buying" aria-selected="false">
                        <i class="fas fa-shopping-cart me-2"></i> My Bids
                    </button>
                </li>
            </ul>

            
            <form action="<?php echo e(route('bidding.list')); ?>" method="GET" class="mb-5 p-4 bg-light rounded shadow-sm">
                <div class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <h5 class="text-primary mb-0"><i class="fas fa-filter me-2"></i> Filter Bids</h5>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold small">Property</label>
                        <select name="property_id" id="property_id" class="form-control form-select">
                            <option value="">All Properties</option>
                            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($property->id); ?>" <?php echo e(request('property_id') == $property->id ? 'selected' : ''); ?>>
                                    <?php echo e($property->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold small">Status</label>
                        <select name="status" id="status" class="form-control form-select">
                            <option value="">All Status</option>
                            <option value="leading" <?php echo e(request('status') == 'leading' ? 'selected' : ''); ?>>Leading</option>
                            <option value="outbid" <?php echo e(request('status') == 'outbid' ? 'selected' : ''); ?>>Outbid</option>
                            <option value="accepted" <?php echo e(request('status') == 'accepted' ? 'selected' : ''); ?>>Accepted</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search me-2"></i> Apply Filter</button>
                    </div>
                </div>
            </form>

            <div class="tab-content" id="pills-tabContent">
                
                <div class="tab-pane fade show active" id="pills-selling" role="tabpanel" aria-labelledby="pills-selling-tab">
                    
                    <div class="table-responsive custom-table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr class="text-uppercase text-black">
                                    <th scope="col">Property</th>
                                    <th scope="col">Property Name</th>
                                    <th scope="col">Bidder Name</th>
                                    <th scope="col">Bid Amount</th>
                                    <th scope="col" class="text-center">Status</th>
                                    <th scope="col" class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $sellingBids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr data-aos="fade-up" data-aos-delay="<?php echo e($loop->iteration * 10); ?>">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?php echo e(asset($bid->property->thumbnail)); ?>" alt="Image"
                                                    class="img-fluid rounded me-3"
                                                    style="width: 80px; height: 60px; object-fit: cover;">
                                            </div>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('properties.show', $bid->property->id)); ?>" target="_blank" class="fw-bold text-dark">
                                                <i class="fas fa-external-link-alt me-1 small"></i> <?php echo e($bid->property->name); ?>

                                            </a>
                                            <span class="d-block text-muted small"><i class="fas fa-map-marker-alt me-1"></i> <?php echo e($bid->property->city); ?></span>
                                        </td>
                                        <td>
                                            <div class="fw-bold"><i class="fas fa-user me-1"></i> <?php echo e($bid->user->name); ?></div>
                                            <small class="text-muted"><?php echo e($bid->user->email); ?></small>
                                        </td>
                                        <td class="fw-bold text-success"><?php echo e('Rp ' . number_format($bid->amount, 0, ',', '.')); ?></td>
                                        <td class="text-center">
                                            <?php if($bid->status == 'leading'): ?>
                                                <span class="badge bg-success"><i class="fas fa-trophy me-1"></i> Leading</span>
                                            <?php elseif($bid->status == 'outbid'): ?>
                                                <span class="badge bg-warning text-dark"><i class="fas fa-exclamation-triangle me-1"></i> Outbid</span>
                                            <?php elseif($bid->status == 'accepted'): ?>
                                                <span class="badge bg-primary"><i class="fas fa-check-circle me-1"></i> Accepted</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger"><?php echo e(ucfirst($bid->status)); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <?php if($bid->status == 'leading' || $bid->status == 'pending'): ?>
                                                <div class="d-flex gap-2 justify-content-center">
                                                    <form action="<?php echo e(route('bidding.accept', $bid->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <button type="submit" class="btn btn-success btn-sm"
                                                            onclick="return confirm('Accept this offer?')">
                                                            <i class="fas fa-check me-1"></i> Accept
                                                        </button>
                                                    </form>
                                                    <form action="<?php echo e(route('bidding.decline', $bid->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm"
                                                            onclick="return confirm('Decline this offer?')">
                                                            <i class="fas fa-times me-1"></i> Decline
                                                        </button>
                                                    </form>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted small"><i class="fas fa-check-double me-1"></i> Completed</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-5">
                                            <i class="fas fa-inbox fa-3x text-muted mb-3 d-block"></i>
                                            <p class="text-black-50">No incoming offers on your properties yet.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                
                <div class="tab-pane fade" id="pills-buying" role="tabpanel" aria-labelledby="pills-buying-tab">
                    <div class="table-responsive custom-table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr class="text-uppercase text-black">
                                    <th scope="col">Property</th>
                                    <th scope="col">Property Name</th>
                                    <th scope="col">Owner Name</th>
                                    <th scope="col">Bid Amount</th>
                                    <th scope="col" class="text-center">Status</th>
                                    <th scope="col" class="text-center">Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $buyingBids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr data-aos="fade-up" data-aos-delay="<?php echo e($loop->iteration * 10); ?>">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?php echo e(asset($bid->property->thumbnail)); ?>" alt="Image"
                                                    class="img-fluid rounded me-3"
                                                    style="width: 80px; height: 60px; object-fit: cover;">
                                            </div>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('properties.show', $bid->property->id)); ?>" target="_blank" class="fw-bold text-dark">
                                                <i class="fas fa-external-link-alt me-1 small"></i> <?php echo e($bid->property->name); ?>

                                            </a>
                                            <span class="d-block text-muted small"><i class="fas fa-map-marker-alt me-1"></i> <?php echo e($bid->property->city); ?></span>
                                        </td>
                                        <td>
                                            <div class="fw-bold"><i class="fas fa-user-tie me-1"></i> <?php echo e($bid->property->owner->name ?? 'Unknown'); ?></div>
                                            <small class="text-muted">Owner</small>
                                        </td>
                                        <td class="fw-bold text-success"><?php echo e('Rp ' . number_format($bid->amount, 0, ',', '.')); ?></td>
                                        <td class="text-center">
                                            <?php if($bid->status == 'leading'): ?>
                                                <span class="badge bg-success"><i class="fas fa-trophy me-1"></i> Leading</span>
                                            <?php elseif($bid->status == 'outbid'): ?>
                                                <span class="badge bg-warning text-dark"><i class="fas fa-exclamation-triangle me-1"></i> Outbid</span>
                                            <?php elseif($bid->status == 'accepted'): ?>
                                                <span class="badge bg-primary"><i class="fas fa-check-circle me-1"></i> Accepted</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary"><?php echo e(ucfirst($bid->status)); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center text-muted">
                                            <i class="fas fa-calendar-alt me-1"></i> <?php echo e($bid->created_at->format('d M Y')); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-5">
                                            <i class="fas fa-shopping-bag fa-3x text-muted mb-3 d-block"></i>
                                            <p class="text-black-50">You haven't placed any bids yet.</p>
                                            <a href="<?php echo e(route('properties.index')); ?>" class="btn btn-primary mt-2">
                                                <i class="fas fa-search me-2"></i> Browse Properties
                                            </a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Documents/Campus/Semester 4/Webpro III/hoonian/resources/views/transaction/list.blade.php ENDPATH**/ ?>