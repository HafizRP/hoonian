<?php $__env->startSection('content'); ?>
    

    <div class="hero">
        <div class="hero-slide">
            <div class="img overlay" style="background-image: url(<?php echo e(asset('assets/images/hero_bg_3.jpg')); ?>"></div>
            <div class="img overlay" style="background-image: url(<?php echo e(asset('assets/images/hero_bg_2.jpg')); ?>"></div>
            <div class="img overlay" style="background-image: url(<?php echo e(asset('assets/images/hero_bg_1.jpg')); ?>"></div>
        </div>

        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-9 text-white">
                    <h1 class="heading text-center" data-aos="fade-up">
                        Easiest way to find your dream home
                    </h1>
                    <form action="<?php echo e(route('properties.index')); ?>" method="GET"
                        class="row g-3 align-items-end form-search" data-aos="fade-up" data-aos-delay="200">

                        <div class="col-md-12">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" class="form-control px-4" value="<?php echo e(request('name')); ?>"
                                placeholder="e.g. New York">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">City</label>
                            <input type="text" name="city" class="form-control" value="<?php echo e(request('city')); ?>"
                                placeholder="City">
                        </div>

                        <div class="col-md-2">
                            <label class="form-label">Min Price</label>
                            <input type="text" name="min_price" class="form-control" value="<?php echo e(request('min_price')); ?>"
                                placeholder="e.g. 100000">
                        </div>

                        <div class="col-md-2">
                            <label class="form-label">Max Price</label>
                            <input type="text" name="max_price" class="form-control"
                                value="<?php echo e(request('max_price')); ?>" placeholder="e.g. 500000">
                        </div>


                        <div class="col-md-3">
                            <label class="form-label">Type</label>
                            <select name="type" class="form-control">
                                <option value=""></option>

                                <?php $__currentLoopData = $properties_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"
                                        <?php echo e(request('type') == $item->id ? 'selected' : ''); ?>> <?php echo e($item->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-2 d-grid">
                            <label class="form-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="section">
        <div class="container">
            <div class="row mb-5 align-items-center">
                <div class="col-lg-6 text-center mx-auto">
                    <h2 class="font-weight-bold text-primary heading">
                        Featured Properties
                    </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="property-slider-wrap">
                        <div class="property-slider">
                            <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="property-item">
                                    <a href="<?php echo e(route('properties.show', $item->id)); ?>" class="img">
                                        <img src="<?php echo e(asset('storage/' . $item->thumbnail)); ?>" alt="Image"
                                            class="img-fluid object-fit-cover" style="aspect-ratio: 4/3;" /> </a>

                                    <div class="property-content">
                                        <div class="price mb-2">
                                            <span><?php echo e('Rp ' . number_format($item->price, 0, ',', '.')); ?></span>
                                        </div>
                                        <div>
                                            <span class="d-block mb-2 text-black-50"><?php echo e($item->name); ?></span>
                                            <span class="city d-block mb-3"><?php echo e($item->city); ?></span>

                                            <div class="specs d-flex mb-4">
                                                <span class="d-block d-flex align-items-center me-3">
                                                    <span class="icon-bed me-2"></span>
                                                    <span class="caption"><?php echo e($item->bedrooms); ?> beds</span>
                                                </span>
                                                <span class="d-block d-flex align-items-center">
                                                    <span class="icon-bath me-2"></span>
                                                    <span class="caption"><?php echo e($item->bathrooms); ?> baths</span>
                                                </span>
                                            </div>

                                            <a href="<?php echo e(route('properties.show', $item->id)); ?>"
                                                class="btn btn-primary py-2 px-3">See
                                                details</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                        </div>

                        <div id="property-nav" class="controls" tabindex="0" aria-label="Carousel Navigation">
                            <span class="prev" data-controls="prev" aria-controls="property"
                                tabindex="-1">Prev</span>
                            <span class="next" data-controls="next" aria-controls="property"
                                tabindex="-1">Next</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section section-properties">
        <div class="container">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
                        <div class="property-item mb-30">
                            <a href="<?php echo e(route('properties.show', $item->id)); ?>" class="img">
                                <img src="<?php echo e(asset('storage/' . $item->thumbnail)); ?>" alt="Image"
                                    class="img-fluid object-fit-cover" style="aspect-ratio: 4/3;" /> </a>

                            <div class="property-content">
                                <div class="price mb-2">
                                    <span><?php echo e('Rp ' . number_format($item->price, 0, ',', '.')); ?></span>
                                </div>
                                <div>
                                    <span class="d-block mb-2 text-black-50"><?php echo e($item->name); ?></span>
                                    <span class="city d-block mb-3"><?php echo e($item->city); ?></span>

                                    <div class="specs d-flex mb-4">
                                        <span class="d-block d-flex align-items-center me-3">
                                            <span class="icon-bed me-2"></span>
                                            <span class="caption"><?php echo e($item->bedrooms); ?> beds</span>
                                        </span>
                                        <span class="d-block d-flex align-items-center">
                                            <span class="icon-bath me-2"></span>
                                            <span class="caption"><?php echo e($item->bathrooms); ?> baths</span>
                                        </span>
                                    </div>

                                    <a href="<?php echo e(route('properties.show', $item->id)); ?>"
                                        class="btn btn-primary py-2 px-3">See
                                        details</a>
                                </div>
                            </div>
                        </div>
                        <!-- .item -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center py-5">
                        <div class="mb-4">
                            <span class="icon-search display-1 text-muted"></span>
                        </div>
                        <h3 class="text-black-50">No properties found</h3>
                        <p class="text-muted">Try adjusting your search criteria or filters.</p>
                        <a href="<?php echo e(route('properties.index')); ?>" class="btn btn-primary mt-3">Clear Filters</a>
                    </div>
                <?php endif; ?>
            </div>
            <?php echo e($properties->links('vendor.pagination.custom')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Documents/Campus/Semester 4/Webpro III/hoonian/resources/views/property/list.blade.php ENDPATH**/ ?>