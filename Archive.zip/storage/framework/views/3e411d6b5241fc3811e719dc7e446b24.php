<!-- resources/views/auth/login.blade.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="author" content="Hoonian" />
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.png')); ?>" />

    <title>Register — Hoonian</title>

    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/icomoon/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/aos.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />

    <style>
        body {
            font-family: 'Work Sans', sans-serif;
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }

        /* --- Bootstrap Carousel Background --- */
        .carousel,
        .carousel-inner,
        .carousel-item,
        .carousel-item img {
            position: absolute;
            width: 100%;
            height: 100%;
            object-fit: cover;
            top: 0;
            left: 0;
            z-index: 0;
        }

        .carousel::after {
            content: "";
            position: absolute;
            inset: 0;
            /* background: rgba(0, 74, 173, 0.55); */
            z-index: 1;
        }

        /* --- Login Card --- */
        .login-card {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            padding: 40px;
            width: 100%;
            max-width: 420px;
            position: relative;
            z-index: 2;
            animation: fadeInUp 0.6s ease forwards;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-card h2 {
            font-weight: 700;
            text-align: center;
            margin-bottom: 10px;
        }

        .login-card p {
            color: #6c757d;
            text-align: center;
            margin-bottom: 30px;
            font-size: 14px;
        }

        .form-control {
            border-radius: 10px;
            height: 45px;
        }

        .btn-primary {
            width: 100%;
            border-radius: 10px;
            font-weight: 600;
            padding: 12px;
            background-color: #004aad;
            border: none;
        }

        .btn-primary:hover {
            background-color: #003580;
        }

        .login-footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }

        .login-footer a {
            color: #004aad;
            text-decoration: none;
            font-weight: 600;
        }

        .login-footer a:hover {
            text-decoration: underline;
        }

        /* Tombol Google */
        .google-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            background: #fff;
            color: #444;
            border: 1px solid #ddd;
            border-radius: 10px;
            font-weight: 600;
            padding: 10px 0;
            transition: all 0.2s ease-in-out;
            margin-top: 15px;
        }

        .google-btn:hover {
            background: #f7f7f7;
        }

        .google-btn img {
            width: 20px;
            margin-right: 8px;
        }

        .divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
        }

        .divider::before,
        .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #ddd;
        }

        .divider span {
            margin: 0 10px;
            color: #999;
            font-size: 13px;
        }
    </style>
</head>

<body>

    <!-- Bootstrap Carousel Background -->
    <div id="bgCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="4000">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?php echo e(asset('assets/images/hero_bg_1.jpg')); ?>" alt="bg1">
            </div>
            <div class="carousel-item">
                <img src="<?php echo e(asset('assets/images/hero_bg_2.jpg')); ?>" alt="bg2">
            </div>
            <div class="carousel-item">
                <img src="<?php echo e(asset('assets/images/hero_bg_3.jpg')); ?>" alt="bg3">
            </div>
        </div>
    </div>

    <!-- Login Card -->
    <div class="login-card">

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <h2>Welcome</h2>
        <p>Daftar ke akun Hoonian kamu</p>

        <form method="POST" action="<?php echo e(route('auth.register')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <input type="text" name="name" class="form-control" placeholder="Name"
                    value="<?php echo e(old('name')); ?>" required />
            </div>
            <div class="mb-3">
                <input type="email" name="email" class="form-control" placeholder="Email"
                    value="<?php echo e(old('email')); ?>" required />
            </div>

            <div class="mb-3">
                <input type="password" name="password" class="form-control" placeholder="Password" required />
            </div>

            <button type="submit" class="btn btn-primary">Login</button>
        </form>

        <div class="divider"><span>atau</span></div>

        <!-- Tombol Google -->
        <a href="<?php echo e(route('auth.google.redirect')); ?>" class="google-btn">
            <img src="https://www.svgrepo.com/show/475656/google-color.svg" alt="Google">
            Login dengan Google
        </a>

        <div class="login-footer">
            <p>Sudah punya akun?
                <a href="<?php echo e(route('login')); ?>">Login Sekarang</a>
            </p>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH /Users/mac/Documents/Campus/Semester 4/Webpro III/hoonian/resources/views/register.blade.php ENDPATH**/ ?>