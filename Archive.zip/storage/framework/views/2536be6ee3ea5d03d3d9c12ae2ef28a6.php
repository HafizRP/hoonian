<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-sm-6 col-md-3">
                <div class="card card-stats card-round">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-icon">
                                <div class="icon-big text-center icon-primary bubble-shadow-small">
                                    <i class="fas fa-warehouse"></i>
                                </div>
                            </div>
                            <div class="col col-stats ms-3 ms-sm-0">
                                <div class="numbers">
                                    <p class="card-category">Total Properties</p>
                                    <h4 class="card-title"><?php echo e($stats['total_count']); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="card card-stats card-round">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-icon">
                                <div class="icon-big text-center icon-success bubble-shadow-small">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="col col-stats ms-3 ms-sm-0">
                                <div class="numbers">
                                    <p class="card-category">Total Value</p>
                                    <h4 class="card-title">Rp <?php echo e(number_format($stats['total_value'], 0, ',', '.')); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-2">
                <div class="card card-stats card-round">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-icon">
                                <div class="icon-big text-center icon-success bubble-shadow-small">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </div>
                            <div class="col col-stats ms-3 ms-sm-0">
                                <div class="numbers">
                                    <p class="card-category">Available</p>
                                    <h4 class="card-title"><?php echo e($stats['available_count']); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-2">
                <div class="card card-stats card-round">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-icon">
                                <div class="icon-big text-center icon-secondary bubble-shadow-small">
                                    <i class="fas fa-home"></i>
                                </div>
                            </div>
                            <div class="col col-stats ms-3 ms-sm-0">
                                <div class="numbers">
                                    <p class="card-category">Sold</p>
                                    <h4 class="card-title"><?php echo e($stats['sold_count']); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-2">
                <div class="card card-stats card-round">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-icon">
                                <div class="icon-big text-center icon-warning bubble-shadow-small">
                                    <i class="fas fa-star"></i>
                                </div>
                            </div>
                            <div class="col col-stats ms-3 ms-sm-0">
                                <div class="numbers">
                                    <p class="card-category">Featured</p>
                                    <h4 class="card-title"><?php echo e($stats['featured_count']); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Card -->
        <div class="card">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <h4 class="card-title">Property List</h4>
                    <a href="<?php echo e(route('backoffice.properties.create')); ?>" class="btn btn-primary btn-round ms-auto">
                        <i class="fa fa-plus"></i>
                        New Property
                    </a>
                </div>
            </div>
            <div class="card-body">
                <!-- Advanced Filters -->
                <div class="card mb-3" style="background-color: #f8f9fa;">
                    <div class="card-body">
                        <form method="GET" action="<?php echo e(route('backoffice.properties')); ?>" id="filterForm">
                            <div class="row align-items-end">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="form-label fw-bold">City</label>
                                        <input type="text" name="city" class="form-control" 
                                               value="<?php echo e(request('city')); ?>" placeholder="e.g. Jakarta" />
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="form-label fw-bold">Min Price</label>
                                        <input type="number" name="min_price" class="form-control" 
                                               value="<?php echo e(request('min_price')); ?>" placeholder="0" />
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="form-label fw-bold">Max Price</label>
                                        <input type="number" name="max_price" class="form-control" 
                                               value="<?php echo e(request('max_price')); ?>" placeholder="999999999" />
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="form-label fw-bold">Owner</label>
                                        <select name="owner_id" class="form-control">
                                            <option value="">All Owners</option>
                                            <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($owner->id); ?>" <?php echo e(request('owner_id') == $owner->id ? 'selected' : ''); ?>>
                                                    <?php echo e($owner->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="form-label fw-bold">Type</label>
                                        <select name="property_type" class="form-control">
                                            <option value="">All Types</option>
                                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($type->id); ?>" <?php echo e(request('property_type') == $type->id ? 'selected' : ''); ?>>
                                                    <?php echo e($type->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary btn-block w-100">
                                            <i class="fa fa-filter"></i> Apply
                                        </button>
                                        <a href="<?php echo e(route('backoffice.properties')); ?>" class="btn btn-secondary btn-block w-100 mt-2">
                                            <i class="fa fa-times"></i> Clear
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- DataTable -->
                <div class="table-responsive">
                    <table id="property-table" class="display table table-striped table-hover" style="opacity: 0;">
                        <thead>
                            <tr>
                                <th>Thumbnail</th>
                                <th>Name</th>
                                <th>City</th>
                                <th>Price</th>
                                <th>Owner</th>
                                <th>Status</th>
                                <th style="width: 10%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="avatar avatar-sm">
                                            <?php
                                                $pic = 'https://via.placeholder.com/50';
                                                if ($item->pictures && count($item->pictures) > 0) {
                                                    $pic = asset($item->pictures[0]); 
                                                }
                                            ?>
                                            <img src="<?php echo e($pic); ?>" alt="..." class="avatar-img rounded-circle">
                                        </div>
                                    </td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->city); ?></td>
                                    <td data-order="<?php echo e($item->price); ?>"><?php echo e('Rp ' . number_format($item->price, 0, ',', '.')); ?></td>
                                    <td>
                                        <?php if($item->owner): ?>
                                            <a href="<?php echo e(route('users.profile', $item->owner->id)); ?>"><?php echo e($item->owner->name); ?></a>
                                        <?php else: ?>
                                            <span class="text-muted">Unknown</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->status == '1'): ?>
                                            <span class="badge badge-success">Available</span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">Sold</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="form-button-action">
                                            <a href="<?php echo e(route('backoffice.properties.edit', $item->id)); ?>" class="btn btn-link btn-primary btn-lg">
                                                <i class="fa fa-edit"></i>
                                            </a>
                                            <button type="button" class="btn btn-link btn-danger" data-bs-toggle="modal"
                                                data-bs-target="#deleteModal<?php echo e($item->id); ?>">
                                                <i class="fa fa-times"></i>
                                            </button>
                                        </div>

                                        <!-- Delete Modal -->
                                        <div class="modal fade" id="deleteModal<?php echo e($item->id); ?>" tabindex="-1"
                                            role="dialog" aria-hidden="true">
                                            <div class="modal-dialog modal-sm" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header border-0">
                                                        <h5 class="modal-title">Confirm Delete</h5>
                                                        <button type="button" class="close" data-bs-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body text-center">
                                                        <p>Are you sure you want to delete <br><b><?php echo e($item->name); ?></b>?</p>
                                                    </div>
                                                    <div class="modal-footer border-0 justify-content-center">
                                                        <form action="<?php echo e(route('backoffice.properties.destroy', $item->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">Yes, Delete!</button>
                                                        </form>
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">No</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.colVis.min.js"></script>

    <script>
        $(document).ready(function() {
            // Get current date for filename
            var today = new Date();
            var dateStr = today.getFullYear() + '-' + 
                         String(today.getMonth() + 1).padStart(2, '0') + '-' + 
                         String(today.getDate()).padStart(2, '0');
            
            // Get filter info for filename
            var filterInfo = '';
            <?php if(request('city')): ?>
                filterInfo += '_<?php echo e(request("city")); ?>';
            <?php endif; ?>
            <?php if(request('min_price') || request('max_price')): ?>
                filterInfo += '_filtered';
            <?php endif; ?>

            // Initialize DataTable with enhanced configuration
            var table = $('#property-table').DataTable({
                "pageLength": 25,
                "lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
                "order": [[ 1, "asc" ]], // Sort by name ascending
                "responsive": true,
                "dom": 'Blfrtip',
                "buttons": [
                    {
                        extend: 'copy',
                        text: '<i class="fa fa-copy"></i> Copy',
                        className: 'btn btn-info btn-sm',
                        exportOptions: { 
                            columns: [1, 2, 3, 4, 5],
                            format: {
                                body: function(data, row, column, node) {
                                    // Remove HTML tags for clean export
                                    return $(data).text();
                                }
                            }
                        },
                        title: 'Property List - ' + dateStr
                    },
                    {
                        extend: 'excel',
                        text: '<i class="fa fa-file-excel"></i> Excel',
                        className: 'btn btn-success btn-sm',
                        exportOptions: { 
                            columns: [1, 2, 3, 4, 5],
                            format: {
                                body: function(data, row, column, node) {
                                    return $(data).text();
                                }
                            }
                        },
                        title: 'Property List Report',
                        filename: 'properties_' + dateStr + filterInfo
                    },
                    {
                        extend: 'pdf',
                        text: '<i class="fa fa-file-pdf"></i> PDF',
                        className: 'btn btn-danger btn-sm',
                        exportOptions: { 
                            columns: [1, 2, 3, 4, 5],
                            format: {
                                body: function(data, row, column, node) {
                                    return $(data).text();
                                }
                            }
                        },
                        title: 'Property List Report',
                        filename: 'properties_' + dateStr + filterInfo,
                        orientation: 'landscape',
                        pageSize: 'A4',
                        customize: function(doc) {
                            doc.styles.title = {
                                fontSize: 16,
                                bold: true,
                                alignment: 'center',
                                margin: [0, 0, 0, 10]
                            };
                            doc.content[1].table.widths = ['20%', '15%', '20%', '20%', '15%'];
                        }
                    },
                    {
                        extend: 'print',
                        text: '<i class="fa fa-print"></i> Print',
                        className: 'btn btn-secondary btn-sm',
                        exportOptions: { 
                            columns: [1, 2, 3, 4, 5],
                            format: {
                                body: function(data, row, column, node) {
                                    return $(data).text();
                                }
                            }
                        },
                        title: 'Property List Report - ' + dateStr,
                        customize: function(win) {
                            $(win.document.body).css('font-size', '10pt');
                            $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                        }
                    },
                    {
                        extend: 'colvis',
                        text: '<i class="fa fa-columns"></i> Columns',
                        className: 'btn btn-primary btn-sm'
                    }
                ],
                "initComplete": function(settings, json) {
                    // Fade in table smoothly
                    $('#property-table').animate({ opacity: 1 }, 600);
                    
                    // Move buttons to the header
                    table.buttons().container().appendTo('.card-header .d-flex');
                    $('.dt-buttons').addClass('me-2');
                    
                    // Remove default DataTables button class for better styling
                    $('.dt-button').removeClass('dt-button');
                }
            });

            // Add search placeholder
            $('div.dataTables_filter input').attr('placeholder', 'Search properties...');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Documents/Campus/Semester 4/Webpro III/hoonian/resources/views/admin/property/index.blade.php ENDPATH**/ ?>