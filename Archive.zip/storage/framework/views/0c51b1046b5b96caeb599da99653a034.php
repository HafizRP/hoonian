<?php if($paginator->hasPages()): ?>
    <div class="row align-items-center py-5">
        <div class="col-lg-3">
            Pagination (<?php echo e($paginator->currentPage()); ?> of <?php echo e($paginator->lastPage()); ?>)
        </div>

        <div class="col-lg-6 text-center">
            <div class="custom-pagination d-inline-flex gap-2">

                
                <?php if($paginator->onFirstPage()): ?>
                    <a href="#" class="disabled">&laquo;</a>
                <?php else: ?>
                    <a href="<?php echo e($paginator->previousPageUrl()); ?>">&laquo;</a>
                <?php endif; ?>

                
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_array($element)): ?>
                        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $paginator->currentPage()): ?>
                                <a href="#" class="active"><?php echo e($page); ?></a>
                            <?php else: ?>
                                <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <?php if($paginator->hasMorePages()): ?>
                    <a href="<?php echo e($paginator->nextPageUrl()); ?>">&raquo;</a>
                <?php else: ?>
                    <a href="#" class="disabled">&raquo;</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /Users/mac/Documents/Campus/Semester 4/Webpro III/hoonian/resources/views/vendor/pagination/custom.blade.php ENDPATH**/ ?>